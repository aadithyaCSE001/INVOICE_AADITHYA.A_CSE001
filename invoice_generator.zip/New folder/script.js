function addItem() {
    const itemContainer = document.getElementById('itemContainer');
    const newItem = document.createElement('div');
    newItem.classList.add('item');
    newItem.innerHTML = `
        <label for="itemDescription">Description:</label>
        <input type="text" name="itemDescription" required><br>
        <label for="itemQuantity">Quantity:</label>
        <input type="number" name="itemQuantity" required><br>
        <label for="itemPrice">Price per Unit:</label>
        <input type="number" name="itemPrice" required><br>
        <label for="itemTax">Tax Rate (%):</label>
        <input type="number" name="itemTax" required><br>
    `;
    itemContainer.appendChild(newItem);
}

document.getElementById('invoiceForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const customerName = document.getElementById('customerName').value;
    const customerAddress = document.getElementById('customerAddress').value;

    const items = document.querySelectorAll('.item');
    let itemDetails = '';
    let totalAmount = 0;

    items.forEach(item => {
        const description = item.querySelector('input[name="itemDescription"]').value;
        const quantity = parseInt(item.querySelector('input[name="itemQuantity"]').value);
        const price = parseFloat(item.querySelector('input[name="itemPrice"]').value);
        const taxRate = parseFloat(item.querySelector('input[name="itemTax"]').value);

        const itemTotal = quantity * price;
        const taxAmount = itemTotal * (taxRate / 100);
        const finalAmount = itemTotal + taxAmount;

        itemDetails += `
            <p>Item: ${description}<br>
            Quantity: ${quantity}<br>
            Price per Unit: ${price.toFixed(2)}<br>
            Tax Rate: ${taxRate.toFixed(2)}%<br>
            Total (including tax): ${finalAmount.toFixed(2)}</p>
            <hr>
        `;

        totalAmount += finalAmount;
    });

    document.getElementById('customerDetails').innerHTML = `
        <h3>Customer Details</h3>
        <p>Name: ${customerName}<br>
        Address: ${customerAddress}</p>
    `;

    document.getElementById('itemDetails').innerHTML = `
        <h3>Item Details</h3>
        ${itemDetails}
    `;

    document.getElementById('totalAmount').innerHTML = `
        <h3>Total Amount Due: ${totalAmount.toFixed(2)}</h3>
    `;

    document.getElementById('invoiceOutput').style.display = 'block';
});

function printInvoice() {
    window.print();
}
